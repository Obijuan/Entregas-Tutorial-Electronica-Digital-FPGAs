## Colección MakerVentura

Corresponde a mi primera colección , creada para realizar los ejercicios

correspondientes al Tutorial 23 del Curso de Electrónica Digital FPGAs Libres



### Contenido

* Carpeta Bloques :

  * Mis_bloques .

  ​	AND-Scramble

  ​	Franky

  ​	Maker_Ventura

  * Tablas .

    * tablas-3.

      tabla-hex-3-5

      tabla-hex-3-6

      tabla-hex-3-7

* Carpeta Ejemplos :

  ​	Test-Franky

  ​	Test-and

