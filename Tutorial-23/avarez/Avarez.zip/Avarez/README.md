# MyCollection Collection

[![Icestudio](https://img.shields.io/badge/collection-icestudio-blue.svg)](https://github.com/FPGAwars/icestudio)
![Version](https://img.shields.io/badge/version-v0.1.0-orange.svg)

Awesome collection.

## Install

* Download the collection
* Install the collection: *Tools > Collections > Add*
* Load the collection: *Select > Collection*

## Blocks
* *Mis_bloques*
  * and-cs
  * avatar
  * franky
* *Tablas*
  * *Tablas-3*
    * tabla-hex-3-5
    * tabla-hex-3-6
    * tabla-hex-3-7

## Examples
* Ejercicio\.21\.2_Test\.AND
* Ejercicio\.21\.3_Test\.FRANKY




## License

Licensed under [GPL-2.0](https://opensource.org/licenses/GPL-2.0).
