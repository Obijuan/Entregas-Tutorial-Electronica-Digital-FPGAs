// Translation document for the collection
// =======================================
// This file contains the texts
// annotated for translation
//
// Instructions:
// 1. Open the PO file with Poedit
// 2. Press "Update" to update from sources

gettext('Mis_bloques');
gettext('Tablas');
gettext('and-cs');
gettext('Puerta AND con icono del Circuit Scramble');
gettext('Puerta AND');
gettext('avatar');
gettext('andres');
gettext('franky');
gettext('Bloque control Franky');
gettext('Corazon genérico para bombear bits a la frecuencia fijada en Hz (por defecto 1Hz)');
gettext('ServoBit para micrservo TowerPro-SG90. Controlador de 1 bit para mover un servo a 2 posiciones. El ángulo entre una posición y otra es de 90 grados');
gettext('Mux 2:1. Bus de 7 bits. ');
gettext('Mux 2:1. Bus de 4 bits. ');
gettext('Agregador de 4 cables a bus de 4bits');
gettext('Separador de bus de 4bits en 4 cables (1 + 1 + 1 + 1)');
gettext('Multiplexor 2:1 de 1-bit');
gettext('Puerta OR');
gettext('Puerta NOT');
gettext('NAND logic gate');
gettext('Transistor');
gettext('Transistor cmos hecho a partir de semiconductores');
gettext('Cristal de Siicio');
gettext('Atomos de silicio');
gettext('Separador de bus de 8bits en 2 (4 + 4)');
gettext('Agregador de 2 buses de 4 a bus de 8bits');
gettext('Controlador PWM para posicionar servos de 20ms. Las unidades de pos son de 10usec');
gettext('Agregador de 2 cables en un bus de 2-bits');
gettext('**Posición 1**: Posición del servo cuando  \nse introduce un 1\n\nEl valor por defecto es de 135 grados\n');
gettext('**Posición 0**: Posición del servo cuando  \nse introduce un 0\n\nEl valor por defecto es de 45 grados');
gettext('**Entrada**: posición a donde llevar  \nel servo (posición 0 ó 1)');
gettext('**Servobit paramétrico** para los microservos **TowerPro SG-90** o compatibles\n\nLos parámetros **P1** y **P0** son las posiciones asociadas a un valor de la entrada de 1 ó 0  \nEstán expresados en **micro-segundos** (usec). Este tiempo es el ancho del pulso\n\nSus **valores** deben estar comprendidos en este rango: \n\n* Extremo derecho: **500 usec**  \n* Extremo izquierdo **2350 usec**\n');
gettext('Mux 2:1 with logic gates');
gettext('Entrada 1');
gettext('Entrada 0');
gettext('Selección');
gettext('Implementación en Verilog');
gettext('Las puertas están construidas a\npartir de transistores');
gettext('Pincha en algún transistor para\nbajar de nivel');
gettext('Nivel 3: Semiconductores');
gettext('Los transistores se crean a \npartir de uniones entre \nsemiconductores, de tipo P y N\nEstán integrados en los dados de\nsilicio en los circuitos integrados');
gettext('Pincha en el bloque para bajar de nivel');
gettext('Nivel 2: MATERIALES');
gettext('Cristal de silicio');
gettext('Los semiconductores se crean a partir de cristales\nde Silicio (Si) que se dopans con impurezas\npara darle las propiedades de semiconductores');
gettext('Pincha en los bloques para bajar de nivel');
gettext('Átomos de Silicio');
gettext('Nivel 1: ATOMOS');
gettext('Los cristales de silicio se forman a \npartir del enlace covalente entre los\nátomos de silicio. Cada uno de ellos \nestá rodeado por 4 átomos de silicio\nformando un tetraedro');
gettext('<B>Posicion del servo</B>\n\nSe especifica en unidades de 10micro-segundos\nEj. pos = 100 --> Pulso de achura 1ms');
gettext('<B>Generación de una señal PWM para posicionamiento de Servos</B>\nEl periodo es de 20ms\nEl ancho del pulso varía entre 0 - 255 (0 - 2.5ms)');
gettext('Tablas-3');
gettext('tabla-hex-3-5');
gettext('Circuito combinacional de 3 entradas y 5 salidas');
gettext('tabla-hex-3-6');
gettext('Circuito combinacional de 3 entradas y 6 salidas');
gettext('tabla-hex-3-7');
gettext('Circuito combinacional de 3 entradas y 7 salidas');
gettext('Ejercicio.21.2_Test.AND');
gettext('**Ejercicio 21.2: Puerta AND del circuit Scramble**\n\nCrear un **bloque** que implemente una puerta AND usando el icono del Circuit Scramble.  \n\n');
gettext('Hacer un **circuito de prueba**, con este nuevo bloque, usando dos interruptores externos para introducir bit por sus entradas y   \nun LED externo conectado a la salida.\n');
gettext('Ejercicio.21.3_Test.FRANKY');
gettext('Separador de bus de 2-bits en dos cables');
gettext('**Ejercicio 21.3: Bloque Franky**\n\nDiseñar un bloque para controlar a Franky. Tendrá **2 puertos de entrada** de un bit (además del de reloj). Uno hará que Franky\ndispare por sus ojos, cuando se ponga a 1, y no dispare mientras esté a 0. El disparo es un parpadeo de los ojos a una frecuencia\ndefinida por el usuario mediante un parámetro. Por** defecto** será de **10Hz**. La otra entrada hará que Franky mire hacia un \nlado (1) o hacia el otro (0). Tendrá como salidas un **puerto de 2 bits** para los **LEDs de los ojos**, y uno de **un bit** para\nel **control del servo** del cuello. Tendrá un **parámetro** para especificar la frecuencia del parpadeo de los ojos en el disparo.\n\n');
