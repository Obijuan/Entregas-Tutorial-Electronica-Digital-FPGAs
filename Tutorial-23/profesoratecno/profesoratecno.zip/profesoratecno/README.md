## Mi primera colección

Esta colección está creada para practicar y espero que sea la primera de muchas. La verdad es que aprender cómo funciona una FPGA, me está llevando bastante tiempo, aunque me tiene totalmente ilusionada y espero poder poner en práctica estos conocimientos en mis clases en el futuro.

Estoy escribiendo en Mark Down ¿Se pueden poner gifs?
Siiii

![Alt Text](C:\Users\profesoratecno\.icestudio\collections\profesoratecno\giphy.gif?raw=true)

Proceso de creación:
* Si pegamos los bloques directamente en la carpeta **blocks**, lo estamos haciendo mal.
![Alt Text](C:\Users\profesoratecno\.icestudio\collections\profesoratecno\Bloques_profesoratecnoCollection.gif?raw=true)
* Para hacerlo bien, hay que crear una carpeta.-

![Alt Text](C:\Users\profesoratecno\.icestudio\collections\profesoratecno\Bloques_profesoratecnoCollection-2.gif?raw=true)
* Así podremos ver nuestros bloques directemente en el menú de icestudio:

![Alt Text](C:\Users\profesoratecno\.icestudio\collections\profesoratecno\Bloques_profesoratecnoCollection-3.gif?raw=true)
