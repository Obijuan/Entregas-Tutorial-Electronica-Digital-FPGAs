## Colección Tablas IceFactory

Esta colección añade todas las tablas 1 a 8 bits de entradas y de 1 a 8 bits de salida, generadas con IceFactory
