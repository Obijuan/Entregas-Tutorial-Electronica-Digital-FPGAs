# Colección Matalobo

Colección realizada por Manuel Andújar Matalobos para el Tutorial 23 de la Academia Jedi de Hardware.

## Bloques
* *Mis_Bloques*
   * Bloque_mi_icono
   * Bloque_AND_2
   * Bloque_Franky
* *Tablas*
   * *Tablas-3*
      * Tabla 3-5
      * Tabla 3-6
      * Tabla 3-7
* *Sumadores*
   * Sumador-Total-2-bits
   * Sumador-Paralelo-4-bits

## Ejemplos
   * Test-And-2
   * Test-Franky

## Authors
* [Manuel Andújar Matalobos (Matalobo)](https://github.com/matalobo)

## License

Licensed under [GPL-2.0](https://opensource.org/licenses/GPL-2.0).
